const express = require('express');
const fs = require('fs');
const path = require('path');
const router = express.Router();
const postsDir = path.join(__dirname, '../posts');

router.get('/', (req, res) => {
  fs.readdir(postsDir, (err, files) => {
    if (err) return res.send('Error reading posts');
    res.render('index', { posts: files });
  });
});

router.get('/new', (req, res) => {
  res.render('new');
});

router.post('/new', (req, res) => {
  const { title, content } = req.body;
  const filename = `${title.replace(/\s+/g, '_')}.txt`;
  fs.writeFile(path.join(postsDir, filename), content, err => {
    if (err) return res.send('Error saving post');
    res.redirect('/');
  });
});

router.get('/post/:filename', (req, res) => {
  const filepath = path.join(postsDir, req.params.filename);
  fs.readFile(filepath, 'utf8', (err, data) => {
    if (err) return res.send('Post not found');
    res.render('view', { title: req.params.filename.replace('.txt', ''), content: data });
  });
});

router.get('/edit/:filename', (req, res) => {
  const filepath = path.join(postsDir, req.params.filename);
  fs.readFile(filepath, 'utf8', (err, data) => {
    if (err) return res.send('Post not found');
    res.render('edit', { filename: req.params.filename, content: data });
  });
});

router.post('/edit/:filename', (req, res) => {
  const filepath = path.join(postsDir, req.params.filename);
  fs.writeFile(filepath, req.body.content, err => {
    if (err) return res.send('Error updating post');
    res.redirect('/');
  });
});

router.post('/delete/:filename', (req, res) => {
  const filepath = path.join(postsDir, req.params.filename);
  fs.unlink(filepath, err => {
    if (err) return res.send('Error deleting post');
    res.redirect('/');
  });
});

module.exports = router;
